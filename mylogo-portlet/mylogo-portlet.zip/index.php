<center>
<b>Sample PHP page as a Portlet</b>
<br/><br/>
The OFS Logo
</br>
</br>
<?php
$firstNumber = 500;
$secondNumber = 500;
?>

<?
echo($firstNumber + $secondNumber);
?>

</center>